package br.senai.rn.agendaspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgendaSpringApplication.class, args);
	}

}
